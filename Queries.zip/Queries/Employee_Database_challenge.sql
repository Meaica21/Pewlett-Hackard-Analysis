-- Deliverable 1: Instructions 1 to 7
SELECT emp_no, first_name, last_name
FROM employees;

SELECT *
FROM employees;

-- Retrieve the title, from_date, and to_date columns from the Titles table.
SELECT title, from_date, to_date
FROM titles;

-- get all employees with birthdate between 1952 and 1955
SELECT emp.emp_no, emp.first_name,emp.last_name,ti.title,ti.from_date,ti.to_date
FROM employees emp 
INNER JOIN titles ti ON emp.emp_no = ti.emp_no
WHERE (emp.birth_date BETWEEN '1952-01-01' AND '1955-12-31') 
ORDER BY emp.emp_no;

-- Create new table for retirement details
SELECT emp.emp_no, emp.first_name,emp.last_name,ti.title,ti.from_date,ti.to_date
INTO retirement_titles
FROM employees emp 
INNER JOIN titles ti ON emp.emp_no = ti.emp_no
WHERE (emp.birth_date BETWEEN '1952-01-01' AND '1955-12-31') 
ORDER BY emp.emp_no;

-- Check the data of newly created table and then export to csv
SELECT * FROM retirement_titles;


-- Deliverable 1: Instructions 8 to 14
-- Use Dictinct with Orderby to remove duplicate rows
SELECT DISTINCT ON (emp_no)emp_no,first_name,last_name,title
FROM retirement_titles
ORDER BY emp_no, to_date DESC;

--Create a Unique Titles table using the INTO clause.
SELECT DISTINCT ON (emp_no)emp_no,first_name,last_name,title
INTO unique_titles
FROM retirement_titles
ORDER BY emp_no, to_date DESC;

SELECT * FROM unique_titles;

-- Deliverable 1: Instructions 15 to 21
SELECT COUNT(emp_no), title
FROM unique_titles
GROUP BY title
ORDER BY COUNT(emp_no) DESC;

--create a Retiring Titles table to hold the required information.
SELECT COUNT(emp_no), title
INTO retiring_titles
FROM unique_titles
GROUP BY title
ORDER BY COUNT(emp_no) DESC;

SELECT * FROM retiring_titles;

-- Deliverable 2: Instructions 1 to 11
SELECT DISTINCT ON (em.emp_no)em.emp_no, em.first_name, em.last_name,em.birth_date,
de.from_date,de.to_date,ti.title
FROM employees em 
INNER JOIN dept_emp de ON em.emp_no = de.emp_no
INNER JOIN titles ti ON em.emp_no =  ti.emp_no
WHERE (de.to_date = '9999-01-01') AND (em.birth_date BETWEEN '1965-01-01' AND '1965-12-31') 
ORDER BY em.emp_no;

-- Create new table for Mentorship Eligibility
SELECT DISTINCT ON (em.emp_no)em.emp_no, em.first_name, em.last_name,em.birth_date,
de.from_date,de.to_date,ti.title
INTO mentorship_eligibilty
FROM employees em 
INNER JOIN dept_emp de ON em.emp_no = de.emp_no
INNER JOIN titles ti ON em.emp_no =  ti.emp_no
WHERE (de.to_date = '9999-01-01') AND (em.birth_date BETWEEN '1965-01-01' AND '1965-12-31') 
ORDER BY em.emp_no;

SELECT * FROM mentorship_eligibilty;




